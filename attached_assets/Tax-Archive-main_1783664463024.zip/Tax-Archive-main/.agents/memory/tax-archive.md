---
name: Tax Archive App
description: Key decisions and quirks for the أرشيف الضرائب artifact at artifacts/tax-archive
---

# Tax Archive App Notes

## Architecture
- Pure localStorage app — no database, fully offline.
- Login: `a12026@gmail.com` / password stored in `tax_admin_password` (default: `A12026`).
- All customer CRUD happens in App.tsx state, persisted to localStorage on every change.

## Chatbot
- Originally designed to call `/api/chatbot` with Gemini.
- Replit AI integrations (Gemini + OpenAI) both require paid account upgrade — user declined.
- **Current implementation: local rule-based bot in ChatbotView.tsx** — no API key needed.
- If user provides a Gemini API key later, add it as `GEMINI_API_KEY` secret and restore the fetch-based implementation.

**Why:** Replit AI integrations returned `awaiting_account_upgrade` for both Gemini and OpenAI; user said to skip AI for now and use whatever works locally.

## Known Design Trade-offs
- Auth is client-side only (localStorage `tax_is_logged_in`). Intentional for offline-first use case.
- Passwords stored in plaintext in localStorage — acceptable for single-user offline archive, not for multi-user/server deployment.

## Critical Fixes Applied
- JSON.parse of localStorage is guarded with try/catch + array validation on boot.
- BackupView validates both `customers` and `trash` arrays + filters malformed customer objects before restore.

## PWA
- manifest.json + sw.js added to public/; index.html has lang="ar" dir="rtl".
